<?php
    //headers
    // use * to allowing anyone without the problem about authentication 
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application.json');
    //for save or create query 
    header('Access-Control-Allow-Methods: POST');
    header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Athorization, X-Requested-With');



    //get row posted data
    $data = json_decode(file_get_contents('php://input'));

	if( isset($data->uname) && $data->upassword )
	{
		$id = rand();
		echo json_encode(
            array('message' => 'Success.','id'=>$id,'username'=>$data->uname,'password'=>$data->upassword )
        );
	}
     else {
        echo json_encode(array('message' => 'Post not created.')); 
    }
?>