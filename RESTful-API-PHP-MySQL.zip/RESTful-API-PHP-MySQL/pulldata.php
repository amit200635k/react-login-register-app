<?php
    //headers
    // use * to allowing anyone without the problem about authentication 
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application.json');
    //for save or create query 
    header('Access-Control-Allow-Methods: POST');
    header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Athorization, X-Requested-With, Authtoken');
 
	
require_once("db.php");
$selSql = "SELECT * FROM `tbl_usermaster`";
$resSel = $conn->query($selSql);
$resData=$resSel-> fetch_all(MYSQLI_ASSOC);
echo json_encode(json_encode(array('status'=>'Success','alldata'=>json_encode($resData)))); 			 


?>