<?php
    //headers
    // use * to allowing anyone without the problem about authentication 
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application.json');
    //for save or create query 
    header('Access-Control-Allow-Methods: POST');
    header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Athorization, X-Requested-With, Authtoken');
 

	$data = json_decode(file_get_contents('php://input'),1);
$headers = apache_request_headers();
  
	//echo json_encode(json_encode(array('message' => $data)));
	//die();
require_once("db.php");
			
					
		$authVal =$headers["Authtoken"];
		$authVal = explode(" ",$authVal);
		$authTokn = $authVal[1];
		if(strlen($authTokn)>1)
		{
			$fname = htmlspecialchars($data['fname']);
			$lname = htmlspecialchars($data['lname']);
			$city = htmlspecialchars($data['city']);
			
			$action = mysqli_real_escape_string($conn,$data["action"]);		
			$dataId= mysqli_real_escape_string($conn,$data["dataId"]); 
			$insSql='';
			if($action =="edit"){
				
				
				
				$insSql = "UPDATE `tbl_usermaster` SET fname='$fname',lname='$lname',city='$city', `modifiedOn`=CURDATE() WHERE `id`='$dataId'";	//`fname`=[value-2],`lname`=[value-3],`email`=[value-4],`mobile`=[value-5],`username`=[value-6],`city`=[value-7],`state`=[value-8],`zip`=[value-9],`jsonData`=[value-10],`createdDate`=[value-11],
			}
			else if($action =="delete"){
				$insSql = "DELETE FROM `tbl_usermaster` WHERE `id`='$dataId'";
			}
			
			//var_dump($insSql);
			$insRes = $conn->query($insSql);
			if($insRes)
				{
					$selSql = "SELECT * FROM `tbl_usermaster`";
					$resSel = $conn->query($selSql);
					$resData=$resSel-> fetch_all(MYSQLI_ASSOC);
					echo json_encode(json_encode(array('status'=>'Success','message' => 'Successfully Saved','icon'=>'success','alldata'=>json_encode($resData)))); 
				}
			else{
				echo json_encode(json_encode(array('status'=>'Error','message' => $conn->error,'icon'=>'error'))); 
			}
			
		}
		else{
			echo json_encode(json_encode(array('status'=>'Error','message' => 'Auhtorization Error','icon'=>'error'))); 
		}



?>