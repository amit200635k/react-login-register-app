<?php
    //headers
    // use * to allowing anyone without the problem about authentication 
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application.json');
    //for save or create query 
    header('Access-Control-Allow-Methods: POST');
    header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Athorization, X-Requested-With, Authtoken');
 
//echo json_encode(json_decode(json_encode(array('message' => 'Success.'))));
//die();
    //get row posted data
    //$data = json_decode(json_encode(file_get_contents('php://input')));
	$data = json_decode(file_get_contents('php://input'),1);
	//print_r($data);	
	$headers = apache_request_headers();
	$heads1 = getallheaders();
	//echo json_encode(json_encode($headers));
	/*foreach ($heads1 as $header => $value) {
		echo "$header: $value <br />\n";
	}*/
	//echo json_encode($heads1);
	
	//echo json_encode(array('message' => 'Success.','id'=>rand(),'data'=>$data, 'hhhh'=>$headers));
	//echo json_encode($headers);
	
	//$auth ='';
	//echo json_encode(array_keys($headers));
	//echo json_encode(array_search("author",array_keys($headers)) );
	//echo json_encode(array('status'=>'Success','message' => 'Successfully Saved','icon'=>'success','alldata'=>json_encode($data))); 
	
require_once("db.php");
			
					
		$authVal =$headers["Authtoken"];
		$authVal = explode(" ",$authVal);
		$authTokn = $authVal[1];
		if(strlen($authTokn)>1)
		{
		
			$fname = mysqli_real_escape_string($conn,$data["fname"]);		
			$lname= mysqli_real_escape_string($conn,$data["lname"]);	
			$email= mysqli_real_escape_string($conn,$data["email"]);	
			$mobile= mysqli_real_escape_string($conn,$data["mobile"]);	
			$username= mysqli_real_escape_string($conn,$data["username"]);	
			$city= mysqli_real_escape_string($conn,$data["city"]);	
			$state= mysqli_real_escape_string($conn,$data["ustate"]);	
			$zip= mysqli_real_escape_string($conn,$data["zip"]);	
			$jsonData= json_encode(json_decode(json_encode($data)));
			//$createdDate	$modifiedOn
			$insSql = "INSERT INTO `tbl_usermaster`(`fname`, `lname`, `email`, `mobile`, `username`, `city`, `state`, `zip`, `jsonData`, `createdDate`) VALUES ('$fname','$lname','$email','$mobile','$username','$city','$state','$zip','$jsonData',CURDATE())";
			//var_dump($insSql);
			$insRes = $conn->query($insSql);
			if($insRes)
				{
					$selSql = "SELECT * FROM `tbl_usermaster`";
					$resSel = $conn->query($selSql);
					$resData=$resSel-> fetch_all(MYSQLI_ASSOC);
					echo json_encode(json_encode(array('status'=>'Success','message' => 'Successfully Saved','icon'=>'success','alldata'=>json_encode($resData)))); 
				}
			else{
				echo json_encode(json_encode(array('status'=>'Error','message' => $conn->error,'icon'=>'error'))); 
			}
			
		}
		else{
			echo json_encode(json_encode(array('status'=>'Error','message' => 'Auhtorization Error','icon'=>'error'))); 
		}


?>